require 'rails_helper'

RSpec.describe UsersController, type: :controller do
    describe "get#new" do
        it "renders the users#new" do
            get :new
        end
    end

end