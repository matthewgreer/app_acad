FactoryBot.define do 
    factory :user do 
        username { Faker::Movies::Ghostbusters.actor }
        password { "staypuft" }
        # association :goals, factory: :goals
        # association :comments, factory: :comments
    end
end