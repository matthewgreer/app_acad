
class Comment < ApplicationRecord

end