
class Goal < ApplicationRecord

end